# Brand — SpecForge PRD Workbench (Warp)

System: Warm dark terminal chrome — parchment type on charred earth, mist borders, restrained Earth Gray pills. Dense desktop utility for PM / eng / design / security review.

## Tokens (Warp contract)

```css
:root {
  --bg: #161412;
  --surface: #1f1d1b;
  --fg: #faf9f6;
  --muted: #868584;
  --border: rgba(226, 226, 226, 0.35);
  --accent: #353534;
}
```

Also bound: `--fg-2` ash, `--meta` purple-tint gray, `--accent-on`, semantic success/warn/danger for status only.

## Type

- Display/Body: `"Matter Regular", "Matter", "Inter", "Noto Sans TC", "PingFang TC", system-ui`
- Mono: `"Geist Mono", ui-monospace, Menlo`

## Posture

1. Warm near-black canvas — never cold/blue dark or pure white UI.
2. Text is parchment, not `#fff`; weight 400 default, 500 only for emphasis.
3. Primary CTA = Earth Gray pill + ash label — no bright blue/green CTAs.
4. Depth via mist borders and opacity veils, not heavy shadows or gradients.
5. Uppercase micro-labels with wide tracking for editorial sections.
